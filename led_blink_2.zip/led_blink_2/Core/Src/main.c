/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "led1202.h"
#include "led12a1.h"


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define MAX_CH_CURRENT ((uint8_t)20) // default: 20
#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))
#define MAX(X, Y) (((X) > (Y)) ? (X) : (Y))
#define M_SIZE 576
#define COLOR_STEP 360
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart2_rx;

/* USER CODE BEGIN PV */
uint8_t DevAddrArray[10];
uint8_t B_matrix[29] =
	{
		1,1,1,0,
		1,0,0,1,
		1,0,0,1,
		1,1,1,0,
		1,0,0,1,
		1,0,0,1,
		1,1,1,0
	};
uint8_t H_matrix[29] =
	{
		0,1,1,0,
		1,0,0,1,
		0,1,0,0,
		0,0,1,0,
		0,0,0,1,
		1,0,0,1,
		0,1,1,0
	};
uint8_t S_matrix[29] =
	{
		1,0,0,1,
		1,0,0,1,
		1,0,0,1,
		1,1,1,1,
		1,0,0,1,
		1,0,0,1,
		1,0,0,1
	};
static uint8_t matrix[M_SIZE];
static uint8_t color_sequence[COLOR_STEP * 4];
uint8_t NumOfDev = 0;
uint8_t txdata[30] = "Hello World!\r\n";
uint8_t rxdata[2];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

static const float hue(float vH)
{
    if (vH < 0.0f) {
        vH += 1.0f;
    }

    if (vH > 1.0f) {
        vH -= 1.0f;
    }

    if ((6.0f * vH) < 1.0f) {
        return (6.0f * vH);
    }

    if ((2.0f * vH) < 1.0f) {
        return 1.0f;
    }

    if ((3.0f * vH) < 2.0f) {
        return (((2.0f - 3.0f * vH) * 2.0f));
    }

    return 0.0f;
}

static uint8_t hsl_r(float h) {

    h = h / 360.0f;
    return (uint8_t)(255.0f * hue(h + (1.0f / 3.0f)));
}

static uint8_t hsl_g(float h) {

    h = h / 360.0f;
    return (uint8_t)(255.0f * hue(h));
}

static uint8_t hsl_b(float h) {

    h = h / 360.0f;
    return (uint8_t)(255.0f * hue(h - (1.0f / 3.0f)));
}


/*
static const float _k(float h, float s, float l, float n) {
	return (float)fmod((double)(n + h / 30.0f), 12.0);
}

static const float _f(float h, float s, float l, float n) {
	s /= 100.0f;
	l /= 100.0f;
	const float a = s * MIN(l, 1.0f - l);
	return l - a * MAX(-1.0f, MIN(_k(h, s, l, n) - 3.0f, MIN(9.0f - _k(h, s, l, n), 1.0f)));
}

static const uint8_t hsl_r(float h, float s, float l) {
	return (uint8_t)(255.0f * _f(h, s, l, 0.0f));
}

static const uint8_t hsl_g(float h, float s, float l) {
	return (uint8_t)(255.0f * _f(h, s, l, 8.0f));
}

static const uint8_t hsl_b(float h, float s, float l) {
	return (uint8_t)(255.0f * _f(h, s, l, 4.0f));
}*/

/* n - nth LED, brightness: [0, 100] */
static void set_led_state(uint8_t dev, uint8_t channel, uint8_t brightness);

static void upload_matrix();
static void set_full_color(uint8_t r, uint8_t g, uint8_t b, uint8_t a);
static void init_matrix();

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	float h;
	for (int i = 0; i < COLOR_STEP; i++)
	{
	  //h = (float)(i) * ;
	  color_sequence[i*4] 		= hsl_r(h);
	  color_sequence[i*4+1] 	= hsl_g(h);
	  color_sequence[i*4+2] 	= hsl_b(h);
	  color_sequence[i*4+3] 	= 100;
	}
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_Delay(100);

  //HAL_UART_Transmit(&huart2, txdata, sizeof(txdata), 100);

  //set_full_color(255, 255, 255, 2);
  init_matrix();


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  uint32_t i = 0;

  //set_full_color(220, 0, 200, 100);
  //upload_matrix();

  char PROJECT_MODE[5] = "1 \r\n";


  const uint8_t inter_d = 5;
  uint8_t shift = 0;
  uint8_t _i = 0;

  while (1)
  {
	  //HAL_UART_Receive(&huart2, PROJECT_MODE, sizeof(PROJECT_MODE), 100);

	  if (PROJECT_MODE[0] == '1')
	  {
		  h = i * 360.0f / (float)COLOR_STEP;
		 set_full_color(hsl_r(h), hsl_g(h), hsl_b(h), 70);
		  upload_matrix();
		  //i %= COLOR_STEP*4;
		  i += 1;
		  HAL_Delay(100);
	  }

	  else if (PROJECT_MODE[0] != '1')
	  {
		  set_full_color(255, 0, 0, 70);
		  upload_matrix();

		  if (i < inter_d) {

		  }

		  else if (i < 2 * inter_d) {
			  _i = i - inter_d;
			  for (uint8_t line = 0; line < 4; line++) {
				  for (uint8_t channel = 0; channel < 4; ++channel) {
					  if (shift - line >= 0 && (shift - line) * 4 < 28) {
						  matrix[line * 4 + channel] = B_matrix[shift - line];
						 }
					  if ((shift - line) * 4 >= 28) {
						  shift = 0;
					  }
				  	  }
				  shift++;
			  }

		  }
		  //else if (i < 2 * inter_d + 7 + inter_d)
		  // else if (i < 2*inter_d + 2*(7 + inter_d))
		  i += 1;
		  upload_matrix();
		  HAL_Delay(1000);
		  set_full_color(0, 0, 255, 10);

	  }

	  else if (PROJECT_MODE[0] == '5')
	  {
		  set_full_color(50, 0, 0, 10);
		  upload_matrix();
	  }

	  else if (PROJECT_MODE[0] == '6')
	  {

	  }

    /* USER CODE END WHILE */


	 /*h = i * 360.0f / (float)COLOR_STEP;
	 set_full_color(hsl_r(h), hsl_g(h), hsl_b(h), 70);
	  upload_matrix();
	  //i %= COLOR_STEP*4;
	  i += 1;
	  HAL_Delay(100);
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSIDiv = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00303D5B;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 25000;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 25000;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 100;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart2, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart2, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED1202_IRQ_Pin */
  GPIO_InitStruct.Pin = LED1202_IRQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(LED1202_IRQ_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
static void set_full_color(uint8_t r, uint8_t g, uint8_t b, uint8_t a)
{
	for (int i = 0; i < M_SIZE; i += 4)
	{
		matrix[i] 	= r;
		matrix[i+1] = g;
		matrix[i+2] = b;
		matrix[i+3] = a;
	}
}

static void upload_matrix()
{
	uint8_t a_shift = 0;
	uint8_t n, n_bright;
	for (uint8_t dev = 0; dev < 4; ++dev)
	  {
		for (uint8_t channel = 0; channel < 12; ++channel)
		{
			a_shift 	= (uint8_t)((float)channel / 3.0f);
			n 			= 16 * dev + channel + a_shift;
			n_bright 	= 16 * dev + 3 * a_shift + 3;
			set_led_state(dev, channel, (uint8_t)((float)matrix[n] * 2)); // * (float)matrix[n_bright] / 100.0f));
		}
	  }
}

static void set_led_state(uint8_t dev, uint8_t channel, uint8_t brightness)
{
	if (brightness == 0) {
		//LED12A1_ChannelDisable(&LED1202Obj, (TypeDefChannel)(LED_CHANNEL_0 << channel),  (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
		brightness += 1;
		//return;
	}

	uint32_t digCurrReg =  (uint8_t)(4095.0f * brightness / 100.0f);
	//LED12A1_ChannelEnable(&LED1202Obj, (TypeDefChannel)(LED_CHANNEL_0 << channel),  (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
	LED12A1_AnalogDimming(&LED1202Obj, (uint8_t)(MAX_CH_CURRENT), channel, (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
	LED12A1_DigitalDimming(&LED1202Obj, &digCurrReg, channel, 0, (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
	//LED12A1_DigitalDimming(&LED1202Obj, &digCurrReg, channel, 0, (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
}

static void init_matrix()
{
	LED12A1_Init();
	NumOfDev = LED12A1_ScanAvailDevice(&LED1202Obj, DevAddrArray);

	for (uint8_t dev = 0;dev<NumOfDev;dev++) {
	  LED12A1_DeviceEnable(&LED1202Obj , (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
	  LED12A1_ChannelDisable( &LED1202Obj , LED_CHANNEL_ALL , (TypedefEnumDevAddr)( LED_DEVICE1 + dev));
	}

	for (uint8_t dev = 0; dev < 4; ++dev) {
		for (uint8_t channel = 0; channel < 12; ++channel) {
			LED12A1_ChannelEnable(&LED1202Obj, (TypeDefChannel)(LED_CHANNEL_0 << channel),  (TypedefEnumDevAddr)(LED_DEVICE1 + dev));
		}
	}

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
